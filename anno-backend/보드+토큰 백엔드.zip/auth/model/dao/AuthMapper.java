package com.kh.semi.auth.model.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.kh.semi.member.model.dto.MemberDto;

@Mapper
public interface AuthMapper {

	@Select("""
				SELECT
			
			""")
	MemberDto loadUser(String username);
	
}
